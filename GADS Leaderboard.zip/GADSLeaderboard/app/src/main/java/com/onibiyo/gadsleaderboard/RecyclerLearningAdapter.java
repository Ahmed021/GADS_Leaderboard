package com.onibiyo.gadsleaderboard;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerLearningAdapter extends RecyclerView.Adapter<RecyclerLearningAdapter.ViewHolder> {

    private String[] learningHours = {"d116df5",
            "36ffc75", "f5cfe78", "5b87628",
            "db8d14e", "9913dc4", "e120f96",
            "466251b"};

    private String[] learnersName = {"Kekayaan", "Teknologi",
            "Keluarga", "Bisnis",
            "Keluarga", "Hutang",
            "Teknologi", "Pidana"};

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_learning_hours, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txtLearnerName.setText(learnersName[position]);
        holder.txtLearningHours.setText(learningHours[position]);
    }

    @Override
    public int getItemCount() {
        return learnersName.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtLearnerName;
        TextView txtLearningHours;
        ImageView imgLearning;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtLearnerName = itemView.findViewById(R.id.txt_name_learning);
            txtLearningHours = (TextView) itemView.findViewById(R.id.txt_learning_hours);
            imgLearning = (ImageView) itemView.findViewById(R.id.image_learning);
        }
    }
}
